import { useState } from "react";
import { type Scenario, type AttackBranch } from "@/data/win2k-scenario";
import ScenarioSelect from "@/components/ScenarioSelect";
import TargetBrief from "@/components/TargetBrief";
import StepView from "@/components/StepView";
import BranchSelect from "@/components/BranchSelect";
import PhaseTransition from "@/components/PhaseTransition";
import CompletionScreen from "@/components/CompletionScreen";

type GameState =
  | { screen: "select" }
  | { screen: "brief"; scenario: Scenario }
  | { screen: "recon"; scenario: Scenario }
  | { screen: "branch"; scenario: Scenario }
  | { screen: "attack"; scenario: Scenario; branch: AttackBranch; step: number }
  | { screen: "exfil"; scenario: Scenario; branch: AttackBranch }
  | { screen: "transition"; scenario: Scenario; branch: AttackBranch }
  | { screen: "defend"; scenario: Scenario; step: number }
  | { screen: "complete"; scenario: Scenario };

const Index = () => {
  const [state, setState] = useState<GameState>({ screen: "select" });
  const [attackScore, setAttackScore] = useState(0);
  const [defendScore, setDefendScore] = useState(0);

  const handleSelect = (scenario: Scenario) => {
    setAttackScore(0);
    setDefendScore(0);
    setState({ screen: "brief", scenario });
  };

  const handleStartAttack = () => {
    if (state.screen === "brief") {
      setState({ screen: "recon", scenario: state.scenario });
    }
  };

  const handleReconNext = (correct: boolean) => {
    if (state.screen === "recon") {
      if (correct) setAttackScore((s) => s + 1);
      setState({ screen: "branch", scenario: state.scenario });
    }
  };

  const handleBranchSelect = (branch: AttackBranch) => {
    if (state.screen === "branch") {
      setState({ screen: "attack", scenario: state.scenario, branch, step: 0 });
    }
  };

  const handleNextAttackStep = (correct: boolean) => {
    if (state.screen === "attack") {
      if (correct) setAttackScore((s) => s + 1);
      const next = state.step + 1;
      if (next >= state.branch.steps.length) {
        setState({ screen: "exfil", scenario: state.scenario, branch: state.branch });
      } else {
        setState({ screen: "attack", scenario: state.scenario, branch: state.branch, step: next });
      }
    }
  };

  const handleExfilNext = (correct: boolean) => {
    if (state.screen === "exfil") {
      if (correct) setAttackScore((s) => s + 1);
      setState({ screen: "transition", scenario: state.scenario, branch: state.branch });
    }
  };

  const handleStartDefend = () => {
    if (state.screen === "transition") {
      setState({ screen: "defend", scenario: state.scenario, step: 0 });
    }
  };

  const handleNextDefendStep = (correct: boolean) => {
    if (state.screen === "defend") {
      if (correct) setDefendScore((s) => s + 1);
      const next = state.step + 1;
      if (next >= state.scenario.defendPhase.length) {
        setState({ screen: "complete", scenario: state.scenario });
      } else {
        setState({ screen: "defend", scenario: state.scenario, step: next });
      }
    }
  };

  const handleRestart = () => {
    setState({ screen: "select" });
    setAttackScore(0);
    setDefendScore(0);
  };

  const totalAttackSteps = (() => {
    if (state.screen === "attack" || state.screen === "exfil" || state.screen === "transition") {
      // recon(1) + branch steps + exfil(1)
      return 1 + (state as any).branch?.steps.length + 1;
    }
    return 5; // fallback
  })();

  const getAttackStepIndex = () => {
    if (state.screen === "recon") return 0;
    if (state.screen === "attack") {
      return 1 + state.step;
    }
    if (state.screen === "exfil" && "branch" in state) {
      return 1 + (state as any).branch.steps.length;
    }
    return 0;
  };

  switch (state.screen) {
    case "select":
      return <ScenarioSelect onSelect={handleSelect} />;
    case "brief":
      return <TargetBrief scenario={state.scenario} onStart={handleStartAttack} onHome={handleRestart} />;
    case "recon":
      return (
        <StepView
          key="recon"
          step={state.scenario.reconStep}
          phase="attack"
          stepIndex={0}
          totalSteps={totalAttackSteps}
          onNext={handleReconNext}
          onHome={handleRestart}
        />
      );
    case "branch":
      return (
        <BranchSelect
          branches={state.scenario.attackBranches}
          onSelect={handleBranchSelect}
          onHome={handleRestart}
        />
      );
    case "attack":
      return (
        <StepView
          key={`atk-${state.branch.id}-${state.step}`}
          step={state.branch.steps[state.step]}
          phase="attack"
          stepIndex={1 + state.step}
          totalSteps={1 + state.branch.steps.length + 1}
          onNext={handleNextAttackStep}
          onHome={handleRestart}
        />
      );
    case "exfil":
      return (
        <StepView
          key="exfil"
          step={state.scenario.exfilStep}
          phase="attack"
          stepIndex={1 + state.branch.steps.length}
          totalSteps={1 + state.branch.steps.length + 1}
          onNext={handleExfilNext}
          onHome={handleRestart}
        />
      );
    case "transition":
      return <PhaseTransition onContinue={handleStartDefend} onHome={handleRestart} />;
    case "defend":
      return (
        <StepView
          key={`def-${state.step}`}
          step={state.scenario.defendPhase[state.step]}
          phase="defend"
          stepIndex={state.step}
          totalSteps={state.scenario.defendPhase.length}
          onNext={handleNextDefendStep}
          onHome={handleRestart}
        />
      );
    case "complete": {
      const maxAttack = 5; // recon + 3 branch steps + exfil
      const maxDefend = state.scenario.defendPhase.length;
      return (
        <CompletionScreen
          onRestart={handleRestart}
          score={{
            attack: attackScore,
            defend: defendScore,
            total: attackScore + defendScore,
            max: maxAttack + maxDefend,
            maxAttack,
            maxDefend,
          }}
        />
      );
    }
  }
};

export default Index;
