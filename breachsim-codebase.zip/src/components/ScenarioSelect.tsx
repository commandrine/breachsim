import { win2kScenario, futureScenarios, type Scenario } from "@/data/win2k-scenario";
import { Lock } from "lucide-react";

interface ScenarioSelectProps {
  onSelect: (scenario: Scenario) => void;
}

const ScenarioSelect = ({ onSelect }: ScenarioSelectProps) => {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6">
      <div className="scanline fixed inset-0 pointer-events-none z-50" />
      
      <div className="max-w-4xl w-full space-y-10">
        <div className="text-center space-y-4">
          <h1 className="font-display text-4xl md:text-5xl font-bold text-primary text-glow tracking-wider">
            BREACH SIM
          </h1>
          <p className="text-muted-foreground font-body text-lg max-w-xl mx-auto">
            Learn cybersecurity by thinking like an attacker — then learn to defend.
          </p>
        </div>

        <div className="space-y-3">
          <h2 className="font-display text-sm tracking-[0.3em] text-terminal-amber text-glow-amber uppercase">
            Select Scenario
          </h2>

          {/* Available scenario */}
          <button
            onClick={() => onSelect(win2kScenario)}
            className="w-full text-left p-5 rounded border border-primary/40 bg-card hover:border-primary hover:border-glow transition-all duration-300 group"
          >
            <div className="flex items-start gap-4">
              <span className="text-3xl">{win2kScenario.icon}</span>
              <div className="flex-1 space-y-1">
                <div className="flex items-center gap-2">
                  <span className="font-display text-lg text-primary text-glow group-hover:text-primary">
                    {win2kScenario.title}
                  </span>
                  <span className="text-xs px-2 py-0.5 rounded bg-primary/20 text-primary border border-primary/30 font-display">
                    AVAILABLE
                  </span>
                </div>
                <p className="text-muted-foreground font-body text-sm">{win2kScenario.description}</p>
              </div>
            </div>
          </button>

          {/* Future scenarios */}
          {futureScenarios.map((s) => (
            <div
              key={s.id}
              className="w-full text-left p-5 rounded border border-border/30 bg-card/50 opacity-50 cursor-not-allowed"
            >
              <div className="flex items-start gap-4">
                <span className="text-3xl grayscale">{s.icon}</span>
                <div className="flex-1 space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-display text-lg text-muted-foreground">{s.title}</span>
                    <span className="text-xs px-2 py-0.5 rounded bg-secondary text-muted-foreground border border-border/30 font-display flex items-center gap-1">
                      <Lock className="w-3 h-3" /> COMING SOON
                    </span>
                  </div>
                  <p className="text-muted-foreground/60 font-body text-sm">{s.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ScenarioSelect;
