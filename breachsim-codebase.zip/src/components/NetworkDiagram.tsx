interface NetworkDiagramProps {
  attackStep: number;
  defendStep: number;
  phase: "attack" | "defend";
}

const NetworkDiagram = ({ attackStep, defendStep, phase }: NetworkDiagramProps) => {
  const isDefend = phase === "defend";
  const step = isDefend ? defendStep : attackStep;

  const ports = [
    { label: "80", y: 95, blocked: isDefend && step >= 0 ? false : false },
    { label: "135", y: 125, blocked: isDefend && step >= 0 },
    { label: "139", y: 155, blocked: isDefend && step >= 0 },
    { label: "445", y: 185, blocked: isDefend && step >= 0 },
    { label: "1433", y: 215, blocked: isDefend && step >= 0 },
  ];

  const defenses: { label: string; y: number; active: boolean }[] = [
    { label: "Firewall", y: 100, active: isDefend && step >= 0 },
    { label: "Hardened SMB", y: 135, active: isDefend && step >= 1 },
    { label: "Patched", y: 170, active: isDefend && step >= 2 },
    { label: "Strong Auth", y: 205, active: isDefend && step >= 3 },
    { label: "Monitoring", y: 240, active: isDefend && step >= 4 },
  ];

  // Attack progress lines
  const attackProgress = !isDefend ? step : -1;

  return (
    <svg viewBox="0 0 480 280" className="w-full max-w-md mx-auto" xmlns="http://www.w3.org/2000/svg">
      {/* Attacker */}
      <g>
        <rect x="10" y="110" width="80" height="60" rx="4" fill="hsl(0 72% 51% / 0.15)" stroke="hsl(0 72% 51% / 0.5)" strokeWidth="1.5" />
        <text x="50" y="137" textAnchor="middle" fill="hsl(0 72% 51%)" fontSize="20">☠️</text>
        <text x="50" y="158" textAnchor="middle" fill="hsl(0 72% 51%)" fontSize="8" fontFamily="Orbitron, sans-serif">ATTACKER</text>
      </g>

      {/* Connection lines from attacker */}
      {attackProgress >= 0 && !isDefend && (
        <line x1="90" y1="140" x2="200" y2="140" stroke="hsl(0 72% 51% / 0.6)" strokeWidth="2" strokeDasharray="4 4">
          <animate attributeName="stroke-dashoffset" from="8" to="0" dur="1s" repeatCount="indefinite" />
        </line>
      )}

      {/* Firewall wall (defense) */}
      {isDefend && step >= 0 && (
        <g>
          <rect x="160" y="75" width="8" height="190" rx="2" fill="hsl(142 70% 45% / 0.3)" stroke="hsl(142 70% 45% / 0.6)" strokeWidth="1" />
          <text x="164" y="70" textAnchor="middle" fill="hsl(142 70% 45%)" fontSize="7" fontFamily="Orbitron, sans-serif">FW</text>
        </g>
      )}

      {/* Server */}
      <g>
        <rect x="200" y="80" width="120" height="160" rx="6" fill="hsl(220 18% 10%)" stroke="hsl(142 30% 20%)" strokeWidth="1.5" />
        <text x="260" y="108" textAnchor="middle" fill="hsl(142 70% 70%)" fontSize="8" fontFamily="Orbitron, sans-serif">WIN2K SERVER</text>

        {/* Ports */}
        {ports.map((p) => (
          <g key={p.label}>
            <rect
              x="205"
              y={p.y}
              width="50"
              height="20"
              rx="2"
              fill={p.blocked ? "hsl(142 70% 45% / 0.1)" : (attackProgress >= 1 && !isDefend ? "hsl(0 72% 51% / 0.15)" : "hsl(220 15% 16%)")}
              stroke={p.blocked ? "hsl(142 70% 45% / 0.4)" : "hsl(142 30% 20% / 0.5)"}
              strokeWidth="1"
            />
            <text x="230" y={p.y + 13} textAnchor="middle" fill={p.blocked ? "hsl(142 70% 45%)" : "hsl(142 70% 70%)"} fontSize="8" fontFamily="Share Tech Mono, monospace">
              :{p.label}
            </text>
            {p.blocked && (
              <text x="248" y={p.y + 14} fill="hsl(142 70% 45%)" fontSize="10">✓</text>
            )}
          </g>
        ))}

        {/* Data */}
        <rect x="268" y="120" width="45" height="110" rx="3" fill={attackProgress >= 4 && !isDefend ? "hsl(0 72% 51% / 0.2)" : "hsl(38 90% 55% / 0.1)"} stroke={attackProgress >= 4 && !isDefend ? "hsl(0 72% 51% / 0.4)" : "hsl(38 90% 55% / 0.3)"} strokeWidth="1" />
        <text x="290" y="145" textAnchor="middle" fill="hsl(38 90% 55%)" fontSize="14">🗄️</text>
        <text x="290" y="160" textAnchor="middle" fill="hsl(38 90% 55%)" fontSize="6" fontFamily="Share Tech Mono, monospace">10K</text>
        <text x="290" y="170" textAnchor="middle" fill="hsl(38 90% 55%)" fontSize="6" fontFamily="Share Tech Mono, monospace">Records</text>
        {isDefend && step >= 4 && (
          <>
            <text x="290" y="195" textAnchor="middle" fill="hsl(142 70% 45%)" fontSize="8">🔒</text>
            <text x="290" y="215" textAnchor="middle" fill="hsl(142 70% 45%)" fontSize="6" fontFamily="Orbitron, sans-serif">SECURED</text>
          </>
        )}
      </g>

      {/* Defense labels */}
      {isDefend && (
        <g>
          {defenses.filter(d => d.active).map((d) => (
            <g key={d.label}>
              <rect x="350" y={d.y - 10} width="110" height="22" rx="3" fill="hsl(142 70% 45% / 0.1)" stroke="hsl(142 70% 45% / 0.3)" strokeWidth="1" />
              <text x="360" y={d.y + 5} fill="hsl(142 70% 45%)" fontSize="7" fontFamily="Orbitron, sans-serif">✓ {d.label}</text>
            </g>
          ))}
        </g>
      )}

      {/* Attack labels */}
      {!isDefend && attackProgress >= 0 && (
        <g>
          {[
            { label: "Scanning...", step: 0 },
            { label: "Enumerating...", step: 1 },
            { label: "Exploiting!", step: 2 },
            { label: "Dumping creds", step: 3 },
            { label: "Exfiltrating!", step: 4 },
          ].filter(a => a.step <= attackProgress).map((a) => (
            <g key={a.label}>
              <text x="50" y={75 + a.step * 16} fill="hsl(0 72% 51% / 0.8)" fontSize="7" fontFamily="Share Tech Mono, monospace">
                › {a.label}
              </text>
            </g>
          ))}
        </g>
      )}
    </svg>
  );
};

export default NetworkDiagram;
