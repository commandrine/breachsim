import { Shield } from "lucide-react";

interface PhaseTransitionProps {
  onContinue: () => void;
  onHome: () => void;
}

const PhaseTransition = ({ onContinue, onHome }: PhaseTransitionProps) => {
  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <div className="scanline fixed inset-0 pointer-events-none z-50" />
      <div className="max-w-xl w-full text-center space-y-8">
        <button
          onClick={onHome}
          className="text-muted-foreground hover:text-foreground text-xs font-display tracking-wide transition-colors"
        >
          ← HOME
        </button>
        <div className="text-6xl">💀 → 🛡️</div>
        <h2 className="font-display text-3xl text-primary text-glow tracking-wider">
          BREACH COMPLETE
        </h2>
        <p className="text-foreground font-body leading-relaxed max-w-md mx-auto">
          You successfully compromised the server and stole 10,000 customer records. 
          Now it's time to switch sides. <span className="text-primary text-glow">Become the defender</span> and 
          learn how to stop the very attack you just performed.
        </p>
        <div className="border border-primary/30 rounded p-4 bg-primary/5 max-w-sm mx-auto">
          <p className="text-muted-foreground font-body text-sm">
            You'll revisit each step of the attack and choose the best defensive control to prevent it.
          </p>
        </div>
        <button
          onClick={onContinue}
          className="font-display text-sm tracking-widest px-8 py-3 rounded bg-primary/20 border border-primary/50 text-primary hover:bg-primary/30 transition-all text-glow flex items-center gap-2 mx-auto"
        >
          <Shield className="w-4 h-4" /> BEGIN DEFENSE
        </button>
      </div>
    </div>
  );
};

export default PhaseTransition;
