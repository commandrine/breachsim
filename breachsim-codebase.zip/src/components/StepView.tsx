import { useState } from "react";
import { type StoryStep } from "@/data/win2k-scenario";
import TerminalText from "./TerminalText";
import TerminalOutput from "./TerminalOutput";
import NetworkDiagram from "./NetworkDiagram";
import { ChevronRight, Info, CheckCircle2, XCircle, ExternalLink } from "lucide-react";

interface StepViewProps {
  step: StoryStep;
  phase: "attack" | "defend";
  stepIndex: number;
  totalSteps: number;
  onNext: (correct: boolean) => void;
  onHome: () => void;
}

const StepView = ({ step, phase, stepIndex, totalSteps, onNext, onHome }: StepViewProps) => {
  const [selected, setSelected] = useState<string | null>(null);
  const [wrongAttempts, setWrongAttempts] = useState<string[]>([]);
  const [showTechNote, setShowTechNote] = useState(false);
  const [showDiagram, setShowDiagram] = useState(false);
  const [narrativeComplete, setNarrativeComplete] = useState(false);
  const [terminalDone, setTerminalDone] = useState(false);

  const selectedOption = step.options.find((o) => o.id === selected);
  const isCorrect = selectedOption?.correct;
  const isAttack = phase === "attack";

  const handleSelect = (optionId: string) => {
    const option = step.options.find((o) => o.id === optionId);
    if (!option) return;

    if (!option.correct) {
      setSelected(optionId);
      setWrongAttempts((prev) => [...prev, optionId]);
    } else {
      setSelected(optionId);
    }
  };

  const handleRetry = () => {
    setSelected(null);
  };

  const availableOptions = step.options.filter(
    (o) => !wrongAttempts.includes(o.id)
  );

  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <div className="scanline fixed inset-0 pointer-events-none z-50" />
      <div className="max-w-2xl w-full space-y-5">
        {/* Header */}
        <div className="flex items-center justify-between gap-2">
          <button
            onClick={onHome}
            className="text-muted-foreground hover:text-foreground text-xs font-display tracking-wide transition-colors"
          >
            ← HOME
          </button>
          <div className={`inline-flex items-center gap-2 px-3 py-1 rounded border font-display text-xs tracking-widest ${
            isAttack
              ? "bg-destructive/20 border-destructive/40 text-destructive text-glow-red"
              : "bg-primary/20 border-primary/40 text-primary text-glow"
          }`}>
            {isAttack ? "☠ ATTACK" : "🛡 DEFEND"} — STEP {stepIndex + 1}/{totalSteps}
          </div>
          <div className="flex items-center gap-3">
            {/* MITRE Badge */}
            {step.mitre && (
              <a
                href={step.mitre.url}
                target="_blank"
                rel="noopener noreferrer"
                className="hidden sm:flex items-center gap-1.5 px-2 py-1 rounded bg-secondary border border-border text-xs text-terminal-cyan hover:border-terminal-cyan/50 transition-colors"
                title={`${step.mitre.tactic}: ${step.mitre.technique}`}
              >
                <span className="font-display tracking-wide">{step.mitre.id}</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            )}
            <div className="flex gap-1">
              {Array.from({ length: totalSteps }).map((_, i) => (
                <div
                  key={i}
                  className={`w-2 h-2 rounded-full ${
                    i < stepIndex ? (isAttack ? "bg-destructive" : "bg-primary") :
                    i === stepIndex ? (isAttack ? "bg-destructive animate-pulse-glow" : "bg-primary animate-pulse-glow") :
                    "bg-secondary"
                  }`}
                />
              ))}
            </div>
          </div>
        </div>

        {/* MITRE info (mobile) */}
        {step.mitre && (
          <a
            href={step.mitre.url}
            target="_blank"
            rel="noopener noreferrer"
            className="sm:hidden flex items-center gap-2 px-3 py-2 rounded bg-secondary border border-border text-xs text-terminal-cyan hover:border-terminal-cyan/50 transition-colors"
          >
            <span className="font-display tracking-wide">MITRE ATT&CK: {step.mitre.id}</span>
            <span className="text-muted-foreground font-body">— {step.mitre.technique}</span>
            <ExternalLink className="w-3 h-3 ml-auto flex-shrink-0" />
          </a>
        )}

        {/* Narrative */}
        <div className="border border-border rounded p-4 bg-card border-glow">
          <TerminalText
            text={step.narrative}
            speed={15}
            onComplete={() => setNarrativeComplete(true)}
            className="text-foreground font-body leading-relaxed"
          />
        </div>

        {/* Prompt & Options */}
        {narrativeComplete && (!selected || (selected && !isCorrect)) && (
          <div className="space-y-3 animate-in fade-in duration-500">
            {/* Wrong answer feedback */}
            {selected && selectedOption && !isCorrect && (
              <div className="border border-terminal-amber/40 bg-terminal-amber/5 rounded p-4 animate-in fade-in duration-300">
                <div className="flex items-center gap-2 mb-2">
                  <XCircle className="w-5 h-5 text-terminal-amber" />
                  <span className="font-display text-sm text-terminal-amber">NOT THE BEST PATH — TRY AGAIN</span>
                </div>
                <p className="text-foreground font-body text-sm leading-relaxed whitespace-pre-line">
                  {selectedOption.feedback}
                </p>
                <button
                  onClick={handleRetry}
                  className="mt-3 font-display text-xs tracking-widest px-4 py-1.5 rounded border border-terminal-amber/50 text-terminal-amber hover:bg-terminal-amber/10 transition-all"
                >
                  ↩ CHOOSE AGAIN
                </button>
              </div>
            )}

            {/* Options (only show when not viewing wrong feedback, or after retry) */}
            {!selected && (
              <>
                <p className="text-terminal-amber text-glow-amber font-display text-sm tracking-wide">
                  {step.prompt}
                </p>
                {availableOptions.map((opt) => (
                  <button
                    key={opt.id}
                    onClick={() => handleSelect(opt.id)}
                    className="w-full text-left p-4 rounded border border-border bg-secondary/50 hover:border-primary/50 hover:bg-secondary transition-all group"
                  >
                    <div className="font-display text-sm text-foreground group-hover:text-primary transition-colors">
                      {opt.label}
                    </div>
                    <p className="text-muted-foreground font-body text-xs mt-1">{opt.description}</p>
                  </button>
                ))}
                {wrongAttempts.length > 0 && (
                  <p className="text-muted-foreground text-xs font-body italic">
                    {wrongAttempts.length} incorrect {wrongAttempts.length === 1 ? "attempt" : "attempts"} — {availableOptions.length} {availableOptions.length === 1 ? "option" : "options"} remaining
                  </p>
                )}
              </>
            )}
          </div>
        )}

        {/* Correct answer: Terminal output + feedback */}
        {selected && isCorrect && (
          <div className="space-y-4 animate-in fade-in duration-500">
            {/* Terminal output animation */}
            {step.terminalOutput && (
              <TerminalOutput
                lines={step.terminalOutput}
                speed={50}
                onComplete={() => setTerminalDone(true)}
              />
            )}

            {/* Feedback (shows after terminal completes, or immediately if no terminal) */}
            {(terminalDone || !step.terminalOutput) && (
              <div className="space-y-4 animate-in fade-in duration-500">
                <div className="border border-primary/40 bg-primary/5 rounded p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <CheckCircle2 className="w-5 h-5 text-primary" />
                    <span className="font-display text-sm text-primary">
                      {wrongAttempts.length === 0 ? "PERFECT CHOICE ★" : "OPTIMAL CHOICE"}
                    </span>
                  </div>
                  <p className="text-foreground font-body text-sm leading-relaxed whitespace-pre-line">
                    {selectedOption!.feedback}
                  </p>
                </div>

                {/* Layperson takeaway */}
                <div className="border border-terminal-amber/30 bg-terminal-amber/5 rounded p-4">
                  <p className="text-foreground font-body text-sm leading-relaxed">
                    {step.takeaway}
                  </p>
                </div>

                {/* Expandable sections */}
                <div className="flex gap-4">
                  <button
                    onClick={() => setShowTechNote(!showTechNote)}
                    className="flex items-center gap-2 text-terminal-cyan text-xs font-display tracking-wide hover:underline"
                  >
                    <Info className="w-3 h-3" />
                    {showTechNote ? "HIDE" : "SHOW"} TECH NOTE
                  </button>
                  <button
                    onClick={() => setShowDiagram(!showDiagram)}
                    className="flex items-center gap-2 text-terminal-amber text-xs font-display tracking-wide hover:underline"
                  >
                    📡 {showDiagram ? "HIDE" : "SHOW"} NETWORK MAP
                  </button>
                </div>

                {showTechNote && (
                  <div className="border border-terminal-cyan/20 rounded p-3 bg-secondary/30 animate-in fade-in">
                    <p className="text-muted-foreground font-body text-xs leading-relaxed">{step.techNote}</p>
                    {step.mitre && (
                      <a
                        href={step.mitre.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 mt-2 text-terminal-cyan text-xs font-display hover:underline"
                      >
                        MITRE ATT&CK: {step.mitre.id} — {step.mitre.technique} <ExternalLink className="w-3 h-3" />
                      </a>
                    )}
                  </div>
                )}

                {showDiagram && (
                  <div className="border border-terminal-amber/20 rounded p-3 bg-secondary/30 animate-in fade-in">
                    <NetworkDiagram
                      attackStep={isAttack ? stepIndex : 4}
                      defendStep={isAttack ? -1 : stepIndex}
                      phase={phase}
                    />
                  </div>
                )}

                {/* Next button */}
                <div className="flex justify-end">
                  <button
                    onClick={() => onNext(wrongAttempts.length === 0)}
                    className={`font-display text-sm tracking-widest px-6 py-2 rounded border transition-all flex items-center gap-2 ${
                      isAttack
                        ? "bg-destructive/20 border-destructive/50 text-destructive hover:bg-destructive/30 text-glow-red"
                        : "bg-primary/20 border-primary/50 text-primary hover:bg-primary/30 text-glow"
                    }`}
                  >
                    CONTINUE <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default StepView;
