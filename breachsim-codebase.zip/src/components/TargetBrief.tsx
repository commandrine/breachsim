import { type Scenario } from "@/data/win2k-scenario";
import { Shield, Crosshair, HelpCircle } from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface TargetBriefProps {
  scenario: Scenario;
  onStart: () => void;
  onHome: () => void;
}

const serviceExplanations: Record<string, string> = {
  "IIS 5.0 (Port 80)": "A web server — like the engine that runs websites. Port 80 is the standard doorway for web traffic.",
  "SMB (Port 445)": "File sharing service — lets computers share files and printers over a network. Attackers love this because it often leaks information.",
  "RPC (Port 135)": "Remote Procedure Call — lets programs on one computer run code on another. Can be exploited for remote access.",
  "NetBIOS (Port 139)": "An older networking protocol for finding and talking to other computers. Often reveals computer names and user info.",
  "MS SQL Server (Port 1433)": "Microsoft's database software — this is where the customer data is stored. An open database port is very dangerous.",
};

const weaknessExplanations: Record<string, string> = {
  "No firewall": "A firewall is like a security guard for network traffic. Without one, every service is exposed to the entire internet.",
  "Default configurations": "The server was set up and never hardened — like leaving your house with the factory-default lock that everyone has a key to.",
  "Unpatched system": "Security fixes (patches) exist but were never installed — like knowing your door lock is broken but never replacing it.",
  "Weak credentials": "Passwords are simple and easy to guess — like using '1234' as your PIN code.",
};

const TargetBrief = ({ scenario, onStart, onHome }: TargetBriefProps) => {
  const t = scenario.targetInfo;

  return (
    <TooltipProvider delayDuration={200}>
      <div className="min-h-screen flex items-center justify-center p-6">
        <div className="scanline fixed inset-0 pointer-events-none z-50" />
        <div className="max-w-2xl w-full space-y-8">
          <button
            onClick={onHome}
            className="text-muted-foreground hover:text-foreground text-xs font-display tracking-wide transition-colors"
          >
            ← HOME
          </button>
          <div className="text-center space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded bg-destructive/20 border border-destructive/40 text-destructive text-glow-red font-display text-xs tracking-widest">
              <Crosshair className="w-3 h-3" /> ATTACKER ROLE
            </div>
            <h2 className="font-display text-2xl text-primary text-glow">TARGET BRIEFING</h2>
            <p className="text-muted-foreground font-body text-sm max-w-md mx-auto">
              Here's what you know about the target server. Tap any item with a <HelpCircle className="w-3 h-3 inline" /> to learn what it means.
            </p>
          </div>

          <div className="border border-border rounded p-5 bg-card space-y-5 border-glow">
            <div>
              <span className="text-terminal-amber text-glow-amber font-display text-xs tracking-widest">OPERATING SYSTEM</span>
              <p className="text-foreground mt-1">{t.os}</p>
              <p className="text-muted-foreground font-body text-xs mt-1">
                A very old operating system from the year 2000 — no longer supported by Microsoft, meaning no new security fixes.
              </p>
            </div>
            <div>
              <span className="text-terminal-amber text-glow-amber font-display text-xs tracking-widest">EXPOSED SERVICES</span>
              <p className="text-muted-foreground font-body text-xs mt-1 mb-2">
                These are programs running on the server that anyone on the internet can reach:
              </p>
              <div className="flex flex-wrap gap-2">
                {t.services.map((s) => (
                  <Tooltip key={s}>
                    <TooltipTrigger asChild>
                      <span className="text-xs px-2 py-1 rounded bg-secondary border border-border text-foreground cursor-help inline-flex items-center gap-1">
                        {s} <HelpCircle className="w-3 h-3 text-muted-foreground" />
                      </span>
                    </TooltipTrigger>
                    <TooltipContent side="bottom" className="max-w-xs text-sm">
                      {serviceExplanations[s] || s}
                    </TooltipContent>
                  </Tooltip>
                ))}
              </div>
            </div>
            <div>
              <span className="text-terminal-amber text-glow-amber font-display text-xs tracking-widest">KNOWN WEAKNESSES</span>
              <div className="flex flex-wrap gap-2 mt-2">
                {t.vulnerabilities.map((v) => (
                  <Tooltip key={v}>
                    <TooltipTrigger asChild>
                      <span className="text-xs px-2 py-1 rounded bg-destructive/10 border border-destructive/30 text-destructive cursor-help inline-flex items-center gap-1">
                        {v} <HelpCircle className="w-3 h-3" />
                      </span>
                    </TooltipTrigger>
                    <TooltipContent side="bottom" className="max-w-xs text-sm">
                      {weaknessExplanations[v] || v}
                    </TooltipContent>
                  </Tooltip>
                ))}
              </div>
            </div>
            <div>
              <span className="text-terminal-amber text-glow-amber font-display text-xs tracking-widest">TARGET DATA</span>
              <p className="text-foreground mt-1 flex items-center gap-2">
                <Shield className="w-4 h-4 text-terminal-amber" /> {t.data}
              </p>
              <p className="text-muted-foreground font-body text-xs mt-1">
                This is the prize — real personal information that would be valuable to steal or sell.
              </p>
            </div>
          </div>

          <div className="text-center">
            <button
              onClick={onStart}
              className="font-display text-sm tracking-widest px-8 py-3 rounded bg-destructive/20 border border-destructive/50 text-destructive hover:bg-destructive/30 hover:border-destructive transition-all text-glow-red"
            >
              ▶ BEGIN ATTACK
            </button>
          </div>
        </div>
      </div>
    </TooltipProvider>
  );
};

export default TargetBrief;
