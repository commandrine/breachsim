import { useState, useEffect } from "react";

interface TerminalOutputProps {
  lines: string[];
  speed?: number;
  onComplete?: () => void;
}

const TerminalOutput = ({ lines, speed = 60, onComplete }: TerminalOutputProps) => {
  const [visibleLines, setVisibleLines] = useState(0);

  useEffect(() => {
    if (visibleLines >= lines.length) {
      onComplete?.();
      return;
    }
    const timeout = setTimeout(() => {
      setVisibleLines((v) => v + 1);
    }, speed);
    return () => clearTimeout(timeout);
  }, [visibleLines, lines.length, speed]);

  return (
    <div className="bg-background border border-border rounded p-4 font-mono text-xs overflow-x-auto max-h-72 overflow-y-auto border-glow">
      {lines.slice(0, visibleLines).map((line, i) => (
        <div key={i} className={`leading-relaxed ${
          line.startsWith(">>") ? "text-terminal-amber text-glow-amber font-bold mt-1" :
          line.startsWith("[+]") || line.startsWith("[*]") ? "text-primary" :
          line.startsWith("[!]") ? "text-destructive" :
          line.startsWith("$") || line.startsWith("msf") || line.startsWith("meterpreter") ? "text-terminal-cyan" :
          line === "" ? "h-2" :
          "text-muted-foreground"
        }`}>
          {line || "\u00A0"}
        </div>
      ))}
      {visibleLines < lines.length && (
        <span className="text-primary animate-pulse-glow">▊</span>
      )}
    </div>
  );
};

export default TerminalOutput;
