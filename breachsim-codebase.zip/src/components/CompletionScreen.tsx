import { Award, RotateCcw, Star, Shield, Crosshair, Trophy } from "lucide-react";
import NetworkDiagram from "./NetworkDiagram";

interface CompletionScreenProps {
  onRestart: () => void;
  score: { attack: number; defend: number; total: number; max: number; maxAttack?: number; maxDefend?: number };
}

const CompletionScreen = ({ onRestart, score }: CompletionScreenProps) => {
  const pct = Math.round((score.total / score.max) * 100);

  const maxAttack = score.maxAttack ?? 5;
  const maxDefend = score.maxDefend ?? 6;

  const getBadges = () => {
    const badges: { icon: string; label: string; color: string }[] = [];
    if (score.attack === maxAttack) badges.push({ icon: "💀", label: "Perfect Attacker", color: "text-destructive" });
    if (score.defend === maxDefend) badges.push({ icon: "🛡️", label: "Master Defender", color: "text-primary" });
    if (pct === 100) badges.push({ icon: "🏆", label: "Flawless Victory", color: "text-terminal-amber" });
    if (pct >= 70 && pct < 100) badges.push({ icon: "⭐", label: "Sharp Analyst", color: "text-terminal-amber" });
    if (pct < 70) badges.push({ icon: "📚", label: "Eager Learner", color: "text-terminal-cyan" });
    return badges;
  };

  const badges = getBadges();

  const learnings = [
    { icon: "🛡️", title: "Firewalls", desc: "Block unnecessary ports with a default-deny policy" },
    { icon: "🚫", title: "Hardening", desc: "Disable anonymous access and unnecessary services" },
    { icon: "🩹", title: "Patching", desc: "Keep systems updated to fix known vulnerabilities" },
    { icon: "🔐", title: "Credential Security", desc: "Use strong passwords and modern hashing" },
    { icon: "📊", title: "Monitoring", desc: "Log and monitor to detect unauthorized access" },
  ];

  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <div className="scanline fixed inset-0 pointer-events-none z-50" />
      <div className="max-w-2xl w-full text-center space-y-6">
        {/* Score ring */}
        <div className="relative inline-flex items-center justify-center w-28 h-28">
          <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90">
            <circle cx="50" cy="50" r="42" fill="none" stroke="hsl(220 15% 16%)" strokeWidth="6" />
            <circle
              cx="50" cy="50" r="42" fill="none"
              stroke={pct === 100 ? "hsl(38 90% 55%)" : "hsl(142 70% 45%)"}
              strokeWidth="6"
              strokeLinecap="round"
              strokeDasharray={`${2 * Math.PI * 42}`}
              strokeDashoffset={`${2 * Math.PI * 42 * (1 - pct / 100)}`}
              className="transition-all duration-1000"
            />
          </svg>
          <div className="absolute flex flex-col items-center">
            <span className="font-display text-2xl text-primary text-glow">{pct}%</span>
            <span className="text-muted-foreground text-xs font-body">SCORE</span>
          </div>
        </div>

        <h2 className="font-display text-3xl text-primary text-glow tracking-wider">
          SIMULATION COMPLETE
        </h2>

        {/* Score breakdown */}
        <div className="flex justify-center gap-6">
          <div className="flex items-center gap-2 px-3 py-2 rounded bg-destructive/10 border border-destructive/30">
            <Crosshair className="w-4 h-4 text-destructive" />
            <span className="font-display text-xs text-destructive">{score.attack}/{maxAttack} ATTACK</span>
          </div>
          <div className="flex items-center gap-2 px-3 py-2 rounded bg-primary/10 border border-primary/30">
            <Shield className="w-4 h-4 text-primary" />
            <span className="font-display text-xs text-primary">{score.defend}/{maxDefend} DEFEND</span>
          </div>
        </div>

        {/* Badges */}
        <div className="flex justify-center gap-3 flex-wrap">
          {badges.map((b) => (
            <div key={b.label} className="flex items-center gap-2 px-3 py-2 rounded bg-card border border-border">
              <span className="text-lg">{b.icon}</span>
              <span className={`font-display text-xs ${b.color}`}>{b.label}</span>
            </div>
          ))}
        </div>

        {/* Final defended diagram */}
        <div className="border border-primary/20 rounded p-4 bg-card max-w-md mx-auto">
          <p className="text-xs font-display text-primary tracking-widest mb-2">FINAL STATE: DEFENDED</p>
          <NetworkDiagram attackStep={4} defendStep={4} phase="defend" />
        </div>

        {/* Learnings */}
        <div className="grid gap-2 text-left max-w-lg mx-auto">
          {learnings.map((l) => (
            <div key={l.title} className="flex items-start gap-3 p-3 rounded border border-border bg-card">
              <span className="text-lg">{l.icon}</span>
              <div>
                <span className="font-display text-sm text-primary">{l.title}</span>
                <p className="text-muted-foreground font-body text-xs mt-0.5">{l.desc}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="pt-2 space-y-3">
          <p className="text-muted-foreground font-body text-sm">
            Remember: <span className="text-terminal-amber text-glow-amber">Defense in depth</span> — no single control is enough. Layer multiple defenses!
          </p>
          <button
            onClick={onRestart}
            className="font-display text-sm tracking-widest px-8 py-3 rounded bg-secondary border border-border text-foreground hover:border-primary/50 transition-all flex items-center gap-2 mx-auto"
          >
            <RotateCcw className="w-4 h-4" /> BACK TO SCENARIOS
          </button>
        </div>
      </div>
    </div>
  );
};

export default CompletionScreen;
