import { type AttackBranch } from "@/data/win2k-scenario";

interface BranchSelectProps {
  branches: AttackBranch[];
  onSelect: (branch: AttackBranch) => void;
  onHome: () => void;
}

const difficultyColor: Record<string, string> = {
  Easy: "text-primary border-primary/30 bg-primary/10",
  Medium: "text-terminal-amber border-terminal-amber/30 bg-terminal-amber/10",
  Hard: "text-destructive border-destructive/30 bg-destructive/10",
};

const BranchSelect = ({ branches, onSelect, onHome }: BranchSelectProps) => {
  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <div className="scanline fixed inset-0 pointer-events-none z-50" />
      <div className="max-w-2xl w-full space-y-6">
        <button
          onClick={onHome}
          className="text-muted-foreground hover:text-foreground text-xs font-display tracking-wide transition-colors"
        >
          ← HOME
        </button>

        <div className="text-center space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded bg-destructive/20 border border-destructive/40 text-destructive text-glow-red font-display text-xs tracking-widest">
            ☠ CHOOSE YOUR ATTACK VECTOR
          </div>
          <h2 className="font-display text-2xl text-primary text-glow">
            MULTIPLE VULNERABILITIES DETECTED
          </h2>
          <p className="text-muted-foreground font-body text-sm max-w-md mx-auto">
            Your recon revealed several attack paths. Each exploits a different weakness in the server.
            Choose your approach — you can replay later to try other paths.
          </p>
        </div>

        <div className="space-y-3">
          {branches.map((branch) => (
            <button
              key={branch.id}
              onClick={() => onSelect(branch)}
              className="w-full text-left p-5 rounded border border-border bg-card hover:border-destructive/50 hover:bg-destructive/5 transition-all group"
            >
              <div className="flex items-start gap-4">
                <span className="text-3xl">{branch.icon}</span>
                <div className="flex-1 space-y-2">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-display text-base text-foreground group-hover:text-destructive transition-colors">
                      {branch.title}
                    </span>
                    <span className={`text-xs px-2 py-0.5 rounded border font-display ${difficultyColor[branch.difficulty]}`}>
                      {branch.difficulty.toUpperCase()}
                    </span>
                  </div>
                  <p className="text-muted-foreground font-body text-sm">{branch.description}</p>
                  <p className="text-muted-foreground font-body text-xs">
                    {branch.steps.length} steps → then exfiltration
                  </p>
                </div>
              </div>
            </button>
          ))}
        </div>

        <p className="text-center text-muted-foreground font-body text-xs italic">
          💡 All paths lead to the same goal: stealing the customer database. The defend phase will cover ALL vectors.
        </p>
      </div>
    </div>
  );
};

export default BranchSelect;
